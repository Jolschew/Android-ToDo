package todo.kebejaol.todo.Webservice;

/**
 * Created by Jan on 26.06.16.
 *
 */

//TODO implement remaining methods
public class Webservice {
    public boolean isConnection()
    {
        return false;
    }
}
